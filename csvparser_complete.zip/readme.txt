install java

start the jar file with

java -jar csvparser-1.0-SNAPSHOT.jar ./<yourfile>.csv <roundnumber>
